import mcp from 'mcp.js';

export default mcp;