## Run the demo
```
npm i
npm run serve
```
